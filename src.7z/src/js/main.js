$(document).ready(function () {
  $(document).click(function () {
    console.log($("#navigation"));
    
    $("#navigation").fadeIn();
  });
  alert('welcome');
  });